Authors of this project:
SAi ANiketh REnukuntla & Ahad Siddqui

-------------------------------------------
This project works all the steps assigned in the assignment.
By running the compileOS file, it runs the required commands and performs operation in the simulator.
